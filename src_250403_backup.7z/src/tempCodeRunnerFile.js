// regionArray = addQueensToRegionsArray();
// console.log("adding queens to regions: ");
// console.log("    ", regionArray);
// generatedBoard.regions = regionArray;
