// import { addAutoX } from "./generate";
// // addAutoX takes r, c, queens array, and board length

// const Values = Object.freeze({
//     EMPTY: " ",
//     AUTOX: "X",
//     QUEEN: "Q",
//     MANUALX: "x",
//   });

// const testQueens = [
//     [0, 'Q', 0, 0, 0, 0],
//     [0, 0, 0, 0, 0, 'Q'],
//     [0, 0, 0, 'Q', 0, 0],
//     ['Q', 0, 0, 0, 0, 0],
//     [0, 0, 'Q', 0, 0, 0],
//     [0, 0, 0, 0, 'Q', 0],
// ];


// // function generateRegionsFromQueens(testQueens) {
// //     let copyQueens = testQueens;
// //     let r = 0;
// //     let c = copyQueens.indexOf(Values.QUEEN);
// //     addAutoX(r, c, copyQueens, 6);
// //     console.log("big test");
// //     console.log(copyQueens);

// // }

// export { generateRegionsFromQueens };